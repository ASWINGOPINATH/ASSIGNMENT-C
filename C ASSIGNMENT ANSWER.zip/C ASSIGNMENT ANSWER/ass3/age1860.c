#include <stdio.h>

void main() {
 int age;

 printf("Enter your age: ");
 scanf("%d", &age);


 if (age >= 18 && age < 60) {
   printf("The age is within the adult range (18-60).\n");
 } else {
   printf("The age is not within the adult range (18-60).\n");
 }

 
}

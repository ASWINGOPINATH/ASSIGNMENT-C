#include <stdio.h>

void main() {
 int number;

 printf("Enter a number: ");
 scanf("%d", &number);

 if (0 < number && number < 10) {
   printf("%d is within the range (0, 10).\n", number);
 } else {
   printf("%d is not within the range (0, 10).\n", number);
 }

}

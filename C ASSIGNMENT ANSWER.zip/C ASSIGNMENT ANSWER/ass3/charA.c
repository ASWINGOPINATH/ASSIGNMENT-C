#include <stdio.h>

void main() {
 char input;

 printf("Enter a character (A or B): ");
 scanf(" %c", &input);  

 
 if (input == 'A' || input == 'B') {
   printf("The input is either 'A' or 'B'.\n");
 } else {
   printf("The input is not 'A' or 'B'.\n");
 }

 
}

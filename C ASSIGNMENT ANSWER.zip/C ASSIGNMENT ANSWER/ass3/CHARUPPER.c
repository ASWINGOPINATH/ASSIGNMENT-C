#include <stdio.h>

void main() {
 char character;

 printf("Enter a character: ");
 scanf("%c", &character);


 if (character >= 'A' && character <= 'Z') {
   printf("'%c' is an uppercase letter.\n", character);
 } else {
   printf("'%c' is not an uppercase letter.\n", character);
 }


}

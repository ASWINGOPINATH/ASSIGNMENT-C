#include <stdio.h>

void main() {
 int age;

 printf("Enter your age: ");
 scanf("%d", &age);

 if (age < 21 && age >= 18) {
   printf("The age is within the range (18, 21).\n");
 } else {
   printf("The age is not within the range (18, 21).\n");
 }

}

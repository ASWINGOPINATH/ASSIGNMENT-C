#include <stdio.h>

void main() {
 int number;

 printf("Enter a number: ");
 scanf("%d", &number);

 if (number % 2 == 0 || number % 5 == 0) {
   printf("%d is divisible by either 2 or 5.\n", number);
 } else {
   printf("%d is not divisible by either 2 or 5.\n", number);
 }

}

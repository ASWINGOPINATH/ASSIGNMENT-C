#include <stdio.h>

void main() {
 char input;

 printf("Enter a character: ");
 scanf(" %c", &input);

 if (!(input == 'X' || input == 'x')) {
   printf("The input is not 'X' or 'x'.\n");
 } else {
   printf("The input is 'X' or 'x'.\n");
 }
}

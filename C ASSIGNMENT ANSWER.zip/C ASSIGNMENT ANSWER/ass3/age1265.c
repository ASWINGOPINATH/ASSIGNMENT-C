#include <stdio.h>

void main() {
 int age;

 printf("Enter the user's age: ");
 scanf("%d", &age);

 if (age < 12 || age > 65) {
   printf("Eligible for discount!\n");
 } else {
   printf("Not eligible for discount.\n");
 }

 
}

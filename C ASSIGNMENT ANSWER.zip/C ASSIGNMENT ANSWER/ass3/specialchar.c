#include <stdio.h>

void main() {
 char character;

 printf("Enter a character: ");
 scanf(" %c", &character);  
 if (!(character == '@' || character == '#' || character == '$')) {
   printf("'%c' is not a special character.\n", character);
 } else {
   printf("'%c' is a special character.\n", character);
 }

}

#include <stdio.h>

void main() {
   int num = 3;  

   
   if ((num % 2 == 0) && (num > 0)) {
       printf("The number is both even and greater than zero\n");
   } else {
       printf("The number is not both even and greater than zero\n");
   }

   
}

#include <stdio.h>

void main() {
 char character;

 printf("Enter a character: ");
 scanf(" %c", &character);  
 if (!(character >= 'a' && character <= 'z') && !(character >= '0' && character <= '9')) {
   printf("'%c' is neither a lowercase letter nor a digit.\n", character);
 } else {
   printf("'%c' is either a lowercase letter or a digit.\n", character);
 }

}

#include <stdio.h>

void main() {
   int age;

   printf("Enter your age: ");
   scanf("%d", &age);

   
   if (age < 18 || age > 65) {
       printf("Your age is considered young or old.\n");
   } else {
       printf("Your age is between 18 and 65.\n");
   }

   
}

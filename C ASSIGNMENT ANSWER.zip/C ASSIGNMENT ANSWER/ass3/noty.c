#include <stdio.h>

void main() {
  char input;

  printf("Enter a character: ");
  scanf(" %c", &input);  

  if (!(input == 'Y' || input == 'y')) {
    printf("The input is not equal to 'Y' or 'y'.\n");
  } else {
    printf("The input is 'Y' or 'y'.\n");
  }

  
}

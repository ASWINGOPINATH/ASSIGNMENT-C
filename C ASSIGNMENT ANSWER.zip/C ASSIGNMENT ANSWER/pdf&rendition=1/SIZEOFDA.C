#include<stdio.h>
#include<conio.h>
void main()
{
int a;
float b;
long c;
char d;
clrscr();
printf("size of int,sizeof(a)");
printf("size of float,sizeof(b)");
printf("size of long, sizeof(c)");
printf("size of double,sizeof(d)");
getch();
}

#include <stdio.h>

void matrixTranspose(int A[][10], int m, int n) {
    int i, j;
    int transpose[n][m];
    
    for (i = 0; i < m; i++) {
        for (j = 0; j < n; j++) {
            transpose[j][i] = A[i][j];
        }
    }
    
    printf("Transpose of the matrix:\n");
    for (i = 0; i < n; i++) {
        for (j = 0; j < m; j++) {
            printf("%d\t", transpose[i][j]);
        }
        printf("\n");
    }
}

void matrixAddition(int A[][10], int B[][10], int m, int n) {
    int i, j;
    int result[m][n];
    
    for (i = 0; i < m; i++) {
        for (j = 0; j < n; j++) {
            result[i][j] = A[i][j] + B[i][j];
        }
    }
    
    printf("Result of matrix addition:\n");
    for (i = 0; i < m; i++) {
        for (j = 0; j < n; j++) {
            printf("%d\t", result[i][j]);
        }
        printf("\n");
    }
}

void matrixMultiplication(int A[][10], int B[][10], int m1, int n1, int m2, int n2) {
    if (n1 != m2) {
        printf("Matrix multiplication not possible!\n");
        return;
    }
    
    int i, j, k;
    int result[m1][n2];
    
    for (i = 0; i < m1; i++) {
        for (j = 0; j < n2; j++) {
            result[i][j] = 0;
            for (k = 0; k < n1; k++) {
                result[i][j] += A[i][k] * B[k][j];
            }
        }
    }
    
    printf("Result of matrix multiplication:\n");
    for (i = 0; i < m1; i++) {
        for (j = 0; j < n2; j++) {
            printf("%d\t", result[i][j]);
        }
        printf("\n");
    }
}

void matrixInverse(int A[][10], int n) {
    // Code for matrix inverse calculation goes here
    // This function can be implemented separately using various algorithms
    
    printf("Matrix inverse calculation is not implemented in this example.\n");
}

int main() {
    int choice, m1, n1, m2, n2, i, j;
    int A[10][10], B[10][10];
    
    printf("Enter the number of rows and columns for matrix A: ");
    scanf("%d %d", &m1, &n1);
    printf("Enter the elements of matrix A:\n");
    for (i = 0; i < m1; i++) {
        for (j = 0; j < n1; j++) {
            scanf("%d", &A[i][j]);
        }
    }
    
    printf("Enter the number of rows and columns for matrix B: ");
    scanf("%d %d", &m2, &n2);
    printf("Enter the elements of matrix B:\n");
    for (i = 0; i < m2; i++) {
        for (j = 0; j < n2; j++) {
            scanf("%d", &B[i][j]);
        }
    }
    
    printf("Menu:\n");
    printf("1. Matrix Transpose\n");
    printf("2. Matrix Addition\n");
    printf("3. Matrix Multiplication\n");
    printf("4. Matrix Inverse (Not implemented)\n");
    printf("Enter your choice: ");
    scanf("%d", &choice);
    
    switch (choice) {
        case 1:
            if (m1 == n1) {
                matrixTranspose(A, m1, n1);
            } else {
                printf("Matrix transpose not possible for non-square matrix!\n");
            }
            break;
        case 2:
            if (m1 == m2 && n1 == n2) {
                matrixAddition(A, B, m1, n1);
            } else {
                printf("Matrix addition not possible for matrices with different dimensions!\n");
            }
            break;
        case 3:
            matrixMultiplication(A, B, m1, n1, m2, n2);
            break;
        case 4:
            if (m1 == n1) {
                matrixInverse(A, n1);
            } else {
                printf("Matrix inverse not possible for non-square matrix!\n");
            }
            break;
        default:
            printf("Invalid choice!\n");
    }
    
    return 0;
}

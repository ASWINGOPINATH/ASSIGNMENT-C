#include<stdio.h>
#include<conio.h>
void main()
{
int a=0,b=1,c,n,i;
clrscr();
printf("Enter the limit");
scanf("%d",&n);
printf("%d",b);
for(i=0;i<=n;i++)
{
c=a+b;
a=b;
b=c;
if(c<=n)
printf("%d",c);
}
getch();
}
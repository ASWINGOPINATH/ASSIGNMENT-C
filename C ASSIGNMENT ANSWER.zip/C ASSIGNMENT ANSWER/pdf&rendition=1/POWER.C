#include<stdio.h>
#include<conio.h>
#include<math.h>
void main()
{
int a,b,c;
clrscr();
printf("enter the first number");
scanf("%d",&a);
printf("enter the second number");
scanf("%d",&b);
c= pow(a,b);
printf("result %d",c);
getch();
}

#include<stdio.h>

int main()
{
char a,b;

printf("enter the first character:");
scanf(" %c",&a);
printf("enter the second character:");
scanf(" %c",&b);
if(a>b)
{
printf(" %c",a);
}
else
{
printf(" %c",b);
}
return 0;
}
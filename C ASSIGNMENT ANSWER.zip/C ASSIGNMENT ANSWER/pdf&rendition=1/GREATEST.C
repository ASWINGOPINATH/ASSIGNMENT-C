#include<stdio.h>
#include<conio.h>
void main()
{
int a,b;
clrscr();
printf("enter the first number");
scanf("%d",&a);
printf("enter the second number");
scanf("%d",&b);
if(a>b)
{
printf("%d",a);
}
else
{
printf("%d",b);
}
getch();
}
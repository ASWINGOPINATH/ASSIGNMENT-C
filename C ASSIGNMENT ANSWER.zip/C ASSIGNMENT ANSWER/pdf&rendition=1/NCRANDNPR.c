#include <stdio.h>

// Function to calculate factorial
unsigned long long factorial(int n) {
    unsigned long long fact = 1;
    for (int i = 1; i <= n; ++i) {
        fact *= i;
    }
    return fact;
}

// Function to calculate nCr (combination)
unsigned long long nCr(int n, int r) {
    if (r > n || n < 0 || r < 0) {
        return 0;
    }
    return factorial(n) / (factorial(r) * factorial(n - r));
}

// Function to calculate nPr (permutation)
unsigned long long nPr(int n, int r) {
    if (r > n || n < 0 || r < 0) {
        return 0;
    }
    return factorial(n) / factorial(n - r);
}

int main() {
    int n, r;
    printf("Enter the value of n: ");
    scanf("%d", &n);
    printf("Enter the value of r: ");
    scanf("%d", &r);

    unsigned long long combination = nCr(n, r);
    unsigned long long permutation = nPr(n, r);

    printf("nCr(%d, %d) = %llu\n", n, r, combination);
    printf("nPr(%d, %d) = %llu\n", n, r, permutation);

    return 0;
}

#include <stdio.h>
#include <string.h>

int main() {
    char str1[100], str2[100];

    printf("Enter String1: ");
    fgets(str1, sizeof(str1), stdin);

    printf("Enter String2: ");
    fgets(str2, sizeof(str2), stdin);

    // Remove newline character from the end of str1
    if (str1[strlen(str1) - 1] == '\n') {
        str1[strlen(str1) - 1] = '\0';
    }

    // Remove newline character from the end of str2
    if (str2[strlen(str2) - 1] == '\n') {
        str2[strlen(str2) - 1] = '\0';
    }

    strcat(str1, " "); // Add space between the strings
    strcat(str1, str2); // Append str2 to str1

    printf("Appended String: \"%s\"\n", str1);

    return 0;
}

#include<stdio.h>
#include<conio.h>
void main()
{
char a,b,c;
clrscr();
printf("enter the uppercase letter\n");
scanf(" %c",&a);
printf("\n enter the lowercase letter\n");
scanf(" %c\n",&b);
c=a+32;
printf(" %c \n",c);

c=b-32;
printf(" %c",c);
getch();
}
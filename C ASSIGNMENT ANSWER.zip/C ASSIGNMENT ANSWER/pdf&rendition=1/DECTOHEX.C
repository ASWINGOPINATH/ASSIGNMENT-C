#include<stdio.h>
#include<conio.h>
void main()
{
int a;
clrscr();
printf("enter the decimal number");
scanf("%d",&a);
printf("hexadecimal number:%x",a);
getch();
}
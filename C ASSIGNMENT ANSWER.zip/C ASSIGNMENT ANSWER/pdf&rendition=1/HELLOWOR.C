#include<stdio.h>
#include<conio.h>
void main()
{
clrscr();
printf("H\nE\nL\nL\nO\nW\nO\nR\nL\nD");
getch();
}
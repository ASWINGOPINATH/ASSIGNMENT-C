#include <stdio.h>

int main() {
    int number, originalNumber, reversedNumber = 0, remainder;

    // Input a 5-digit number
    printf("Enter a 5-digit number: ");
    scanf("%d", &number);

    // Store the original number
    originalNumber = number;

    // Reverse the number
    while (number != 0) {
        remainder = number % 10;
        reversedNumber = reversedNumber * 10 + remainder;
        number /= 10;
    }

    // Check if the original number and reversed number are equal
    if (originalNumber == reversedNumber) {
        printf("The original number %d and the reversed number %d are equal.\n", originalNumber, reversedNumber);
    } else {
        printf("The original number %d and the reversed number %d are not equal.\n", originalNumber, reversedNumber);
    }

    return 0;
}

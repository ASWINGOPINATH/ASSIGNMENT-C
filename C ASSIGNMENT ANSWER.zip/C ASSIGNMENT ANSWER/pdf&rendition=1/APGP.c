#include <stdio.h>
#include<math.h>
// Function to print Arithmetic Progression (AP)
void printAP(int n, int a, int d) {
    printf("Arithmetic Progression (AP) with first term %d and common difference %d:\n", a, d);
    for (int i = 0; i < n; ++i) {
        printf("%d ", a + i * d);
    }
    printf("\n");
}

// Function to print Geometric Progression (GP)
void printGP(int n, int a, int r) {
    printf("Geometric Progression (GP) with first term %d and common ratio %d:\n", a, r);
    for (int i = 0; i < n; ++i) {
        printf("%d ", a * (int)pow(r, i));
    }
    printf("\n");
}

// Function to print Harmonic Progression (HP)
void printHP(int n, int a, int r) {
    printf("Harmonic Progression (HP) with first term %d and common ratio %d:\n", a, r);
    for (int i = 0; i < n; ++i) {
        printf("%.2f ", (float)a / (a + i * r));
    }
    printf("\n");
}

int main() {
    int n, a, d, r;

    // Input n, common difference (d), and common ratio (r)
    printf("Enter the number of terms (n): ");
    scanf("%d", &n);
    printf("Enter the first term (a): ");
    scanf("%d", &a);
    printf("Enter the common difference for AP (d): ");
    scanf("%d", &d);
    printf("Enter the common ratio for GP and HP (r): ");
    scanf("%d", &r);

    // Print AP, GP, and HP
    printAP(n, a, d);
    printGP(n, a, r);
    printHP(n, a, r);

    return 0;
}

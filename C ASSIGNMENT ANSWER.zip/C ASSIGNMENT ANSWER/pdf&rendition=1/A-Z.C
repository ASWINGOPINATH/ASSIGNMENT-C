#include<stdio.h>
#include<conio.h>
void main()
{
char i;
clrscr();
printf("character a-z\n");
for(i='a';i<='z';i++)
{
printf("%c",i);

}

getch();
}
#include<stdio.h>
#include<conio.h>
void main()
{
int a;
clrscr();
printf("enter the hex value");
scanf("%x",&a);
printf("decimal value:%d",a);
getch();
}
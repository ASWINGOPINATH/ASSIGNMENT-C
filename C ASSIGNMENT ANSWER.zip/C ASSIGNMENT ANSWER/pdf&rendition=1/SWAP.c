#include <stdio.h>

void swapArrays(int arr1[], int arr2[], int size) {
    // Perform swapping element by element without using extra array
    for (int i = 0; i < size; i++) {
        // Swap elements of arr1 and arr2 using XOR operation (no need of temporary variable)
        arr1[i] = arr1[i] ^ arr2[i];
        arr2[i] = arr1[i] ^ arr2[i];
        arr1[i] = arr1[i] ^ arr2[i];
    }
}

int main() {
    int arr1[10], arr2[10];
    
    printf("Enter the 1st array (10 elements): ");
    for (int i = 0; i < 10; i++) {
        scanf("%d", &arr1[i]);
    }
    
    printf("Enter the 2nd array (10 elements): ");
    for (int i = 0; i < 10; i++) {
        scanf("%d", &arr2[i]);
    }
    
    printf("Before swapping:\n");
    printf("1st array: ");
    for (int i = 0; i < 10; i++) {
        printf("%d ", arr1[i]);
    }
    printf("\n2nd array: ");
    for (int i = 0; i < 10; i++) {
        printf("%d ", arr2[i]);
    }
    printf("\n");
    
    swapArrays(arr1, arr2, 10);
    
    printf("After swapping:\n");
    printf("1st array: ");
    for (int i = 0; i < 10; i++) {
        printf("%d ", arr1[i]);
    }
    printf("\n2nd array: ");
    for (int i = 0; i < 10; i++) {
        printf("%d ", arr2[i]);
    }
    printf("\n");
    
    return 0;
}

  #include<stdio.h>
  #include<conio.h>
  void main()
  {
  char a;
  clrscr();
  printf("Enter the character");
  scanf("%c",&a);
  printf("ASCII value of %d",a);
  getch();
  }
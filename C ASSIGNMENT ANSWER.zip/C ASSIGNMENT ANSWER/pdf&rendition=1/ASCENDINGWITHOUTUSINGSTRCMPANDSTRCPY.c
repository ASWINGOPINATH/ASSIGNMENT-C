#include <stdio.h>

void sortNamesWithoutStrcmp(char names[][50], int n) {
    int i, j;
    char temp[50];

    for (i = 0; i < n - 1; i++) {
        for (j = i + 1; j < n; j++) {
            if (names[i][0] > names[j][0]) {
                // Swap names
                strcpy(temp, names[i]);
                strcpy(names[i], names[j]);
                strcpy(names[j], temp);
            }
        }
    }
}

int main() {
    char names[10][50] = {"Ravi", "Arjun", "Prasad", "Hari", "Sebastian", "Mallikarjun", "Renjith", "Sabir", "Raja", "Afsal"};
    int i;

    sortNamesWithoutStrcmp(names, 10);

    printf("Sorted names in ascending order:\n");
    for (i = 0; i < 10; i++) {
        printf("%s\n", names[i]);
    }

    return 0;
}

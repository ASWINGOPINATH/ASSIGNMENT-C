#include<stdio.h>
#include<conio.h>
void main()
{
int a;
clrscr();
printf("enter the first number");
scanf("%d",&a);
if(a%2==0)
{
printf("even");
}
else
{
printf("odd");
}
getch();
}
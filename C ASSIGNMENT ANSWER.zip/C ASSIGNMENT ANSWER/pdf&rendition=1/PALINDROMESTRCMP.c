#include <stdio.h>
#include <stdbool.h>
#include <string.h>

bool isPalindromeWithStrcmp(char str[]) {
    int length = strlen(str);
    int i, j;

    for (i = 0, j = length - 1; i < j; i++, j--) {
        if (str[i] != str[j]) {
            return false;
        }
    }
    return true;
}

int main() {
    char str[100];
    char reversedStr[100];

    printf("Enter a string: ");
    scanf("%s", str);

    strcpy(reversedStr, str);
    strrev(reversedStr);

    if (strcmp(str, reversedStr) == 0) {
        printf("Palindrome\n");
    } else {
        printf("Not a palindrome\n");
    }

    return 0;
}

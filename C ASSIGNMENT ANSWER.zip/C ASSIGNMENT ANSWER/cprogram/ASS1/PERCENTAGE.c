#include<stdio.h>
#include<math.h>
void main()
{
    int y,x,z;
    printf("enter the first number");
    scanf("%d",&x);
    printf("enter the second number");
    scanf("%d",&y);
    z=((y-x)/x)*100;
    printf("%d",z);
}
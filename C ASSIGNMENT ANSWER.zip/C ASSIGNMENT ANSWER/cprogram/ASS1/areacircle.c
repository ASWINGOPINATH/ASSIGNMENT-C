#include<stdio.h>
void main()
{
    float r,a;
    printf("enter the radius");
    scanf("%f",&r);
    a=3.14*r*r;
    printf("%f",a);
}
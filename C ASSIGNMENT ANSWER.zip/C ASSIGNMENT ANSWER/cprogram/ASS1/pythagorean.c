#include<stdio.h>
#include<math.h>
void main()
{
    float x1,x2,y1,y2,c,s;
    printf("enter the firstpont");
    scanf("%f",&x1);
    printf("enter the secondpoint");
    scanf("%f",&x2);
    printf("enter the thirdpoint");
    scanf("%f",&y1);
    printf("enter the fourthpoint");
    scanf("%f",&y2);
    c=(x2-x1)*(x2-x1)+(y2-y1)*(y2-y1);
    s=sqrt(c);
    printf("%f",s);

}
#include<stdio.h>
void main()
{
    int a,b,c,d;
    printf("enter the first number");
    scanf("%d",&a);
    printf("enter the second number");
    scanf("%d",&b);
    c=a/b;
    d=a%b;
    printf("%d",c);
    printf("\n %d",d);
}
#include<stdio.h>
void main()
{
    float f,i;
    printf("enter the inches");
    scanf("%f",&i);
    f=i/12;
    printf("%f",f);
}
#include<stdio.h>
void main()
{
    float k,m;
    printf("enter the kilometer");
    scanf("%f",&k);
    m=k/1.6093;
    printf("%f",m);
}
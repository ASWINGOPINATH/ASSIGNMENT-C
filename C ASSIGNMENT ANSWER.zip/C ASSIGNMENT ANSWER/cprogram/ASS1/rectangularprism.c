#include<stdio.h>
void main(){
    int l,w,h,v;
    printf("enter the length");
    scanf("%d",&l);
    printf("enter the width");
    scanf("%d",&w);
    printf("enter the height");
    scanf("%d",&h);
    v=l*w*h;
    printf("%d",v);
}
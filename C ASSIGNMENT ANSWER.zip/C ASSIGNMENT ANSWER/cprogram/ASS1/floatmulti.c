#include<stdio.h>
void main()
{
    float a,b,c;
    printf("enter the first number");
    scanf("%f",&a);
    printf("enter the second number");
    scanf("%f",&b);
    c=a*b;
    printf("%f",c);
}
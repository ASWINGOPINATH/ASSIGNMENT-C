#include<stdio.h>
void main()
{
    int minute,second;
    printf("enter the second");
    scanf("%d",&second);
    minute=second/60;
    printf("%d",minute);

}
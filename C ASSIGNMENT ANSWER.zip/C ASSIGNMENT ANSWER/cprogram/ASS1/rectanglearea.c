#include<stdio.h>
void main()
{
    int l,w,a;
    printf("enter the length");
    scanf("%d",&l);
    printf("enter the width");
    scanf("%d",&w);
    a=l*w;
    printf("%d",a);
}
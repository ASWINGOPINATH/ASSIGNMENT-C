#include <stdio.h>

void main() {
  float op, dp, da, fp;

  printf("Enter the original price of the item: ");
  scanf("%f", &op);

  printf("Enter the discount percentage: ");
  scanf("%f", &dp);

  da = op * dp / 100;
  fp= op - da;

  printf("The final price of the item after applying a discount is: %.2f\n", fp);

  
}
#include<stdio.h>
#include<math.h>
void main()
{
    float c,p,r,n,s,a,b,j;
    printf("enter the principal");
    scanf("%f",&p);
    printf("enter the rate");
    scanf("%f",&r);
    printf("enter the number of years");
    scanf("%f",&n);
    s=r/100;
    a=1+s;
    b=pow(a,n);
    j=p*b;
    c=j-p;
    printf("%f",c);
}
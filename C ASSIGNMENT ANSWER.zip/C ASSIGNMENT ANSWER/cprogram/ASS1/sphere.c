#include<stdio.h>
void main()
{
    float r,v;
    printf("enter the radious of sphere");
    scanf("%f",&r);
    v=(4/3)*3.14*r*r*r;
    printf("%f",v);
}
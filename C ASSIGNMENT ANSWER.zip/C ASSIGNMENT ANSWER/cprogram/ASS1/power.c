#include<stdio.h>
#include<math.h>
void main()
{
    int a,b;
    printf("enter the number");
    scanf("%d",&a);
    b=pow(a,2);
    printf("%d",b);
}
#include<stdio.h>
void main()
{
    int a = 2;
int b = 4;
int c = b + a * a / b - a;
printf("%d",c);
}
#include<stdio.h>
void main()
{
    int a,b,h;
    printf("enter the base");
    scanf("%d",&b);

    printf("enter the height");
    scanf("%d",&h);
    
    a=b*h/2;
    printf("%d",a);
}
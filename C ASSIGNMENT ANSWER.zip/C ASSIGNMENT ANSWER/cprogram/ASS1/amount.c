#include <stdio.h>

void main() {
  float amountPaid, cost, amountchange;

  printf("Enter the amount paid");
  scanf("%f", &amountPaid);

  printf("Enter the cost of the item");
  scanf("%f", &cost);

  amountchange = amountPaid - cost;
  

  printf(" %f", amountchange);

 
}

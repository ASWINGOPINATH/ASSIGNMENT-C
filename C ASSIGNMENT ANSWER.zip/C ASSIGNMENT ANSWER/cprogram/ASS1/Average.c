#include<stdio.h>
void main()
{
int a,b,c,d,s;
printf("enter the first number");
scanf("%d",&a);
printf("enter the second number");
scanf("%d",&b);
printf("enter the third number");
scanf("%d",&c);
d=a+b+c;
s=d/3;
printf("%d",d);
printf("\n %d",s);
}
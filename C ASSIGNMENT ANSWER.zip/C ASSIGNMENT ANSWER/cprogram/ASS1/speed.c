#include<stdio.h>
void main(){
    float s,d,t;
    printf("enter the distance");
    scanf("%f",&d);
    printf("enter the time");
    scanf("%f",&t);
    s=d/t;
    printf("%f",s);
}
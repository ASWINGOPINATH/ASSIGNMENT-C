#include<stdio.h>
void main(){
    int userage,specifiedage;
    printf("enter the userage:");
    scanf("%d",&userage);
    printf("enter the specifiedage:");
    scanf("%d",&specifiedage);
    if(userage!=specifiedage){
        printf("not equal");
    }
    else{
        printf("equal");
    }
}
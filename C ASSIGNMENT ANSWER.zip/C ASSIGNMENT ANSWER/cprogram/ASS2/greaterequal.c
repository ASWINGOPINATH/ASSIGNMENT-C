#include<stdio.h>
void main()
{
    int a;
    int minvalue=10;
    printf("enter the  number:");
    scanf("%d",&a);
    if(a>=minvalue){
        printf("number is greater than minvalue");
    }
    else{
        printf("number is less than minvalue");
    }

}
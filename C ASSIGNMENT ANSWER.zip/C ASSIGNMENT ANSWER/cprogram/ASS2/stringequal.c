#include<stdio.h>
#include<string.h>
void main(){
    char str1[100],str2[40];
    printf("enter the first string:");
    scanf("%s",&str1);
    printf("enter the second string:");
    scanf(" %s",&str2);
    if(strcmp(str1,str2))
    {
        printf("two strings are equal");
    }
    else{
        printf("two strings are not equal");
    }
}
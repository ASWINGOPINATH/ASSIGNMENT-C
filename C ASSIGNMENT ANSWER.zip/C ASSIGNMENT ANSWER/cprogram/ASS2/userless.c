#include<stdio.h>
void main(){
    int userinput,specifiedvalue;
    printf("Enter the user input:");
    scanf("%d",&userinput);
    printf("Enter the specifiedvalue:");
    scanf("%d",&specifiedvalue);
    if(userinput<specifiedvalue){
        printf("user input is less");
    }
    else{
        printf("user input is greater");
    }
}
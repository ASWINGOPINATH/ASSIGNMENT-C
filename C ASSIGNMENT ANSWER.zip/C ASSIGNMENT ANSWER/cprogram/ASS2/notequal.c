#include<stdio.h>
void main()
{
    float x,y;
    printf("first number:");
    scanf("%f",&x);
    printf("second number:");
    scanf("%f",&y);
    if(x!=y){
        printf("not equal");
    }
    else{
        printf("equal");
    }
}

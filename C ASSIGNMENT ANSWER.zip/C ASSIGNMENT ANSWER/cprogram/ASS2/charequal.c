#include<stdio.h>
void main()
{
    char a,b;
    printf("enter the first character:");
    scanf("%c",&a);
    printf("enter the second character: ");
    scanf(" %c",&b);
    if(a==b){
        printf("first and second character are equal");

    }
    else{
        printf("first and second character are not equal");
    }
}
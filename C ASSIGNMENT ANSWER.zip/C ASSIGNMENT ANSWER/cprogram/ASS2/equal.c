#include<stdio.h>

void main(){

    int a,b;
    printf("enter the first number");
    scanf("%d",&a);
    printf("enter the second number");
    scanf("%d",&b);
    if (a==b)
    {
               printf("first and second number are equal");
    }
    else{
        printf("first and second number are not equal");
    }
}

#include<stdio.h>
void main(){
    int a;
    printf("ENTER THE USER AGE:");
    scanf("%d",&a);
    if(a<=50){
        printf("USER AGE IS LESS THAN 50");
    }
    else{
        printf("USER AGE IS GREATER THAN 50");
    }
}
#include<stdio.h>
void main()
{
    char a,b;
    printf("enter the first character:");
    scanf("%c",&a);
    printf("enter the second character:");
    scanf(" %c",&b);
    if(a>b){
        printf("firstcharacter is greater than second");
    }
    else{
        printf("firstcharacter is less than second");
    }

}
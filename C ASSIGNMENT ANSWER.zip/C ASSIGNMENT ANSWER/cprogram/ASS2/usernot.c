#include<stdio.h>
void main()
{
    int a;
    int specificvalue=20;
    printf("enter the user input:s");
    scanf("%d",&a);
    if(a!=specificvalue){
        printf("user input and specific value are not equal");
    }
    else{
        printf("user input and specific value are equal");
    }
}
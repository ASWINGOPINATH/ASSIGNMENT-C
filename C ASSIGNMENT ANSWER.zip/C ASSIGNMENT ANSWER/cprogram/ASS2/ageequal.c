#include<stdio.h>
void main(){
    int userage,specifiedage;
    printf("Enter the user age:");
    scanf("%d",&userage);
    printf("Enter the specifiedage:");
    scanf("%d",&specifiedage);
    if(userage==specifiedage){
        printf("Two ages are equal");
    }
    else{
        printf("Two ages are not equal");
    }
}
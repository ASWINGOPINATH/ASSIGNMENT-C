#include<stdio.h>
void main()
{
    int a,b;
    printf("enter the first number:");
    scanf("%d",&a);
    printf("enter the second number:");
    scanf("%d",&b);
    if(a>b){
        printf("the first number is greater");

    }
    else{
        printf("the second number is greater");
    }
}
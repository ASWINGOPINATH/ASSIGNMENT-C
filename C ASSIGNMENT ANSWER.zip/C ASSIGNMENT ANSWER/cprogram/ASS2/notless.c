#include<stdio.h>
void main()
{
    int a,b;
    printf("Enter the first number:");
    scanf("%d",&a);
    printf("Enter the second number:");
    scanf("%d",&b);
    if(a >= b)
    {
        printf("first number is not less than the second number");
    }
    else{
        printf("first number is less than the second number");
    }
}
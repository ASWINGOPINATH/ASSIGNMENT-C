#include<stdio.h>
void main()
{
    int userage;
    int minage=50;
    printf("enter the user age:");
    scanf("%d",&userage);
    if(userage>minage){
        printf("user age is greater thanminage");

    }
    else{
        printf("user age is less than minage");
    }
}
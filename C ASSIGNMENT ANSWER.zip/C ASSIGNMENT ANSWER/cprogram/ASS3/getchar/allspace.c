#include <stdio.h>

void main() {
    printf("Enter a string with spaces: ");

    int ch;
    while ((ch = getchar()) != '\n' && ch != EOF) {
       
        if (ch != ' ') {
            
            putchar(ch);
        }
    }

    printf("\n");

    
}

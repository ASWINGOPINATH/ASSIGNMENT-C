#include <stdio.h>

void main() {
    char ch;
    int vowelCount = 0;
    printf("Enter a string: ");

    while ((ch = getchar()) != '\n') {
        
        if (ch == 'a' || ch == 'e' || ch == 'i' || ch == 'o' || ch == 'u' ||ch == 'A' || ch == 'E' || ch == 'I' || ch == 'O' || ch == 'U') 
            {
            putchar(vowelCount++);
        }
    }

   printf("%d",vowelCount);
 
}

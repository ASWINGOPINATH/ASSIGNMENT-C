#include <stdio.h>

void main() {
    printf("Enter a sentence: ");

    int maxChars = 100;
    char sentence[maxChars];

    int index = 0;
    char ch;
    while ((ch = getchar()) != '\n' && index < maxChars - 1) {
        sentence[index] = ch;
        index++;
    }
    sentence[index] = '\0'; 

  
    printf("Reversed sentence: ");
    for (int i = index - 1; i >= 0; i--) {
        putchar(sentence[i]);
    }

    printf("\n");

    
}

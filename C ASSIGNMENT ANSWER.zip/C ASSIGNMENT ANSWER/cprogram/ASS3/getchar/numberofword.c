#include <stdio.h>

void main() {
    printf("Enter a sentence: ");

    int ch;
    int wordCount = 0;
    int inWord = 0; 

    while ((ch = getchar()) != '\n' && ch != EOF) {
        
        if (ch == ' ' || ch == '\t' || ch == '\n') {
            inWord = 0; 
        } else {
            
            if (!inWord) {
                wordCount++;
                inWord = 1; 
            }
        }
    }

    printf("Word count: %d\n", wordCount);


}

#include <stdio.h>

void main() {
    printf("Enter a string: ");

    int ch;
    while ((ch = getchar()) != '\n' && ch != EOF) {
        if (ch >= 'a' && ch <= 'z') {
            
            ch = ch - 'a' + 'A';
        }

        putchar(ch);
    }

    printf("\n");

    
}

#include <stdio.h>

void main() {
    printf("Enter a string: ");

    int ch;
    while ((ch = getchar()) != '\n' && ch != EOF) {
       
        printf("ASCII value of '%c': %d\n", ch, ch);
    }

   
}

#include <stdio.h>

void main() {
    printf("Enter a line of text: ");

    int c;

    while ((c = getchar()) != '\n') {
       
        putchar(c);
    }

    printf("\n");

    
}

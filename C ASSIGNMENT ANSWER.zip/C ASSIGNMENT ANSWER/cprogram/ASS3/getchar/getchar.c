#include<stdio.h>
void main(){
    char c;
    printf("Enter the character:");
    c=getchar();
    putchar(c);
}
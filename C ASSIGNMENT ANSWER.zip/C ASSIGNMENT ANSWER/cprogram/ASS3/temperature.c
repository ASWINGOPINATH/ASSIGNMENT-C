#include<stdio.h>
void main(){
    float c,f;
    printf("enter the temperature in celsious:");
    scanf("%f",&c);
    printf("%f",c*1.8+32);
}
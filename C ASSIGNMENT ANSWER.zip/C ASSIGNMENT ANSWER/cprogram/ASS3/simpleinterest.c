#include<stdio.h>
void main(){
    int p,r,t,s;
    printf("Enter the principal:");
    scanf("%d",&p);
    printf("Enter the rate:");
    scanf("%d",&r);
    printf("Enter the time:");
    scanf("%d",&t);
    printf("%d",p*r*t/100);
}
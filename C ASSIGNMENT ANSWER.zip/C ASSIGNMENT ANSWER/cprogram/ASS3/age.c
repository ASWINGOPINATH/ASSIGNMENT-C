#include<stdio.h>
void main(){
    int age;
    printf("Enter the age:");
    scanf("%d",&age);
    printf("%d",age);
}
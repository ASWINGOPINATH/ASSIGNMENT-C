#include <stdio.h>

void main() {
    int ch;

    printf("Enter a string: ");
    while ((ch = getchar()) != '\n') {
       
        if (ch >= 'A' && ch <= 'Z') {
            
            putchar(ch);
        }
    }
 printf("\n");
   
}

#include<stdio.h>
void main(){
    printf("This \t is a simple \b program\n");
}
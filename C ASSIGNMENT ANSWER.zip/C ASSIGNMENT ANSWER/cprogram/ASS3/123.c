#include<stdio.h>
#include<conio.h>
void main(){
    char ch;
    ch=getch();
    putchar('e');
    putchar(ch);
}

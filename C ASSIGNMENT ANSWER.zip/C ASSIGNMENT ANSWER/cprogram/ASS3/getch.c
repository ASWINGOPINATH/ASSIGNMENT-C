#include<stdio.h>
#include<conio.h>
void main(){
    char c;
    printf("Enter a character: ");
    c = getchar();
    printf("You entered: ");
    putchar(c);
    printf("\n");
    
}


#include<stdio.h>

void main() {
    
    float myFloat = 10.425869; 
    printf(" Floating-Point Number: %.2f\n", myFloat);
   
}

#include <stdio.h>
#include <string.h>
#include <ctype.h>

#define MAX_LENGTH 100


int isPalindrome(char str[]) {
    int left = 0;
    int right = strlen(str) - 1;

    while (left < right) {
        while (!isalnum(str[left]) && left < right) {
            left++;
        }

      
        while (!isalnum(str[right]) && left < right) {
            right--;
        }

        if (tolower(str[left]) != tolower(str[right])) {
            return 0; 
        }

        left++;
        right--;
    }

    return 1; 
}

int main() {
    char inputString[MAX_LENGTH];

    
    printf("Enter a string: ");
    gets(inputString);

    
    if (isPalindrome(inputString)) {
        printf("The string is a palindrome.\n");
    } else {
        printf("The string is not a palindrome.\n");
    }

    return 0;
}

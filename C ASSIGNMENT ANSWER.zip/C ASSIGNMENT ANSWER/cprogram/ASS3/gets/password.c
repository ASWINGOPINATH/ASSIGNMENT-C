#include <stdio.h>
#include <conio.h>

void main() {
    char password[20];
    char ch;
    int i = 0;
    printf("Enter password: ");
    while (1) {
        ch = getch();
        if (ch == 13) { 
            password[i] = '\0'; 
            break;
        } else if (ch == 8 && i > 0) { 
            printf("\b \b"); 
            i--;
        } else if (i< password - 1) {
            password[i] = ch;
            printf("*"); 
            i++;
        }
    }

    printf("\nPassword entered: %s\n", password);

}
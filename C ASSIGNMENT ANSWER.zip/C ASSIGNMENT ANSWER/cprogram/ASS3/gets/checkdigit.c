#include <stdio.h>
#include <ctype.h>

void main() {
    char ch;
    printf("Enter a character: ");
    ch = getchar();

    if (isdigit(ch)) {
        printf("The character is a digit.\n");
    } else {
        printf("The character is not a digit.\n");
    }

    
}

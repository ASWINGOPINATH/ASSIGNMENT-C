#include <stdio.h>
#include<string.h>
void main()
{
    char str[80];
    int i, w = 0;

    printf("Enter a sentence: ");
    gets(str);

    for (i = 0; str[i] != '\0'; i++)
    {
        
        if (str[i] == ' ')
        {
            w++;
        }
    }

    printf("The number of words = %d", w + 1);

}
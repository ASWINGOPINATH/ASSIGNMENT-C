#include <stdio.h>

void main() {
    char str[100];

    printf("Enter a string: ");
    gets(str);

    printf(" Entered: %s\n", str);

   
}

#include <stdio.h>
#include <string.h>

#define MAX_STRINGS 10
#define MAX_LENGTH 100

void main() {
    char strings[MAX_STRINGS][MAX_LENGTH];
    int i, numStrings;

    printf("Enter the number of strings: ");
    scanf("%d", &numStrings);

    while (getchar() != '\n');

    for (i = 0; i < numStrings; i++) {
        printf("Enter string %d: ", i + 1);
        gets(strings[i]);
    }

    printf("\nStrings in reverse order:\n");
    for (i = numStrings - 1; i >= 0; i--) {
        printf("%s\n", strings[i]);
    }


}

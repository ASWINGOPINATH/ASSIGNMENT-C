#include <stdio.h>
#include <string.h>

#define MAX_LENGTH 100

void main() {
    char inputString[MAX_LENGTH];

    printf("Enter a string: ");
    gets(inputString);

    int length = strlen(inputString);
    printf("Number of characters: %d\n", length);

}

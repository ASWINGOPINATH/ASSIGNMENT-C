#include <stdio.h>
#include<conio.h>  
void main() {
    char c;
    printf("Enter characters press q to quit:");
    do {
        c = getch();  
        putchar(c);   
    } while (c != 'q');

    printf("\nProgram terminated by 'q'\n");  
}

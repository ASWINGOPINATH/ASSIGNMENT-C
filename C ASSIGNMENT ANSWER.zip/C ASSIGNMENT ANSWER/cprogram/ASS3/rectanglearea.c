#include<stdio.h>
void main()
{
    int l,w,a;
    printf("Enter the length:");
    scanf("%d",&l);
    printf("Enter the width:");
    scanf("%d",&w);
    printf("%d",l*w);
}
#include <stdio.h>
#include <string.h>
#include <ctype.h>


int is_alphanumeric(char c) {
    return isalnum(c);
}


char to_lower(char c) {
    return tolower(c);
}


int is_palindrome(char *str) {
    int left = 0;
    int right = strlen(str) - 1;
    
    while (left < right) {
       
        while (left < right && !is_alphanumeric(str[left]))
            left++;
        
       
        while (left < right && !is_alphanumeric(str[right]))
            right--;
        
      
        if (left < right && to_lower(str[left]) != to_lower(str[right]))
            return 0; 
        
        left++;
        right--;
    }
    
    return 1; 
}

int main() {
    char str[100];
    
    printf("Enter a string: ");
    fgets(str, sizeof(str), stdin);
    
  
    if (str[strlen(str) - 1] == '\n')
        str[strlen(str) - 1] = '\0';
    
    if (is_palindrome(str))
        printf("The string is a palindrome.\n");
    else
        printf("The string is not a palindrome.\n");
    
    return 0;
}



#include <stdio.h>
void main() {
  int n, a[100];
  printf("Enter the number of elements : ");
  scanf("%d", &n);

  for (int i = 0; i < n; i++) {
    printf("Enter number in array:");
    scanf("%d", &a[i]);
  }

  for (int i = 1; i < n; i++) {
    if (a[0] < a[i]) {
      a[0] = a[i];
    }
  }
  printf("Largest element = %d", a[0]); 
}

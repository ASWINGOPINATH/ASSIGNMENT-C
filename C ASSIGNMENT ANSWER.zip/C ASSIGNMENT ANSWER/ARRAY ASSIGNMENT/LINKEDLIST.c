#include <stdio.h>
#include <stdlib.h>

struct Node {
    int data;
    struct Node *next;
};

void main() {
    int arr[5] = {8, 3, 7, 12};
    struct Node *first = NULL, *temp = NULL, *last = NULL;

    for (int i = 0; i < 4; i++) {
        struct Node *newNode = (struct Node *)malloc(sizeof(struct Node));
        newNode->data = arr[i];
        newNode->next = NULL;

        if (first == NULL) {
            first = temp = last = newNode;
        } else {
            temp->next = newNode;
            temp = newNode;
            last = newNode;
        }
    }
}
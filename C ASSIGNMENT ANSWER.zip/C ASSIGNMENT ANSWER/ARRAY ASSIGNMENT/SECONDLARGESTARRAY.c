#include <stdio.h>

void main() {
    int a[20],size,i,l,sl;
    printf("ENTER THE SIZE OF ARRAY:");
    scanf("%d",&size);
    printf("ENTER THE ARRAY ELEMENT:");
    for(i=0;i<size;i++){
        scanf("%d",&a[i]);
    } 
    for ( i = 0; i < size; i++) {
        if (a[i] > l) {
           sl = l; 
            l = a[i]; 
        } else if (a[i] > sl && a[i] != l) {
            sl = a[i]; 
        }
    }
    printf("Second largest element in the array: %d\n", sl);   
}

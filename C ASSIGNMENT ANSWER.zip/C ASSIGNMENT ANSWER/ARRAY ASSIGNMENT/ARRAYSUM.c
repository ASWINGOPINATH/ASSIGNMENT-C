#include<stdio.h>
void main(){
    int a[10],i,size,sum=0;
    printf("enter the array size:");
    scanf("%d",&size);
    printf("enter the array element:");
    for(i=0;i<size;i++){
        scanf("%d",&a[i]);
    }
    for(i=0;i<size;i++){
        sum=sum+a[i];
    }
    printf("sum=%d",sum);
}
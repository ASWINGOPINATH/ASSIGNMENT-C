#include<stdio.h>
void printArray(int arr[], int size) {
    for (int i = 0; i < size; i++) {
        printf("%d ", arr[i]);
    }
    printf("\n");
}
void Union(int a1[], int size1, int a2[], int size2) {
    int i = 0, j = 0;
    while (i < size1 && j < size2) {
        if (a1[i] < a2[j]) {
            printf("%d ", a1[i++]);
        } else if (a2[j] < a1[i]) {
            printf("%d ", a2[j++]);
        } else {
            printf("%d ", a1[i++]);
            j++;
        }
    }
    while (i < size1) {
        printf("%d ", a1[i++]);
    }
    while (j < size2) {
        printf("%d ", a2[j++]);
    }
    printf("\n");
}
int main() {
    int a1[] = {1, 3, 5, 7};
    int a2[] = {2, 4, 6, 7};
    int size1 = sizeof(a1) / sizeof(a1[0]);
    int size2 = sizeof(a2) / sizeof(a2[0]);
    printf("Array 1: ");
    printArray(a1, size1);
    printf("Array 2: ");
    printArray(a2, size2);
    printf("Union: ");
    Union(a1, size1, a2, size2);
   
}
 
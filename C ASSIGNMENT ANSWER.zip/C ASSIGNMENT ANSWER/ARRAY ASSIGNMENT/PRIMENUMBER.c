#include<stdio.h>

void main() {
   int a[10], i, s, j, p;
   printf("Enter size of an array:");
   scanf("%d", &s);
   printf("Enter array elements:");
   for (i = 0; i < s; i++) {
       scanf("%d", &a[i]);
   }
   printf("All prime Numbers:");
   for (i = 0; i < s; i++) {
          j=2;
          p=1;
       while (j < a[i]) {
           if (a[i] % j == 0) {
               p = 0;
               break;
           }
           j++;
       }
       if (p == 1) {
           printf("%d ", a[i]);
       }
   }
}

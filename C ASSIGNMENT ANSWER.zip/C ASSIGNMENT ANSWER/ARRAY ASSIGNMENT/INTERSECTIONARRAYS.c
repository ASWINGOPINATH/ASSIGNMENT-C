#include <stdio.h>
int existsInArray(int arr[], int size, int key) {
    for (int i = 0; i < size; i++) {
        if (arr[i] == key) {
            return 1; 
        }
    }
    return 0; 
}
void main() {
    int size1, size2;
    printf("Enter the size of the first array: ");
    scanf("%d", &size1);
    int array1[size1];
    printf("Enter elements of the first array: ");
    for (int i = 0; i < size1; i++) {
        scanf("%d", &array1[i]);
    }
    printf("Enter the size of the second array: ");
    scanf("%d", &size2);
    int array2[size2];
    printf("Enter elements of the second array: ");
    for (int i = 0; i < size2; i++) {
        scanf("%d", &array2[i]);
    }
    printf("Intersection of the two arrays: ");
    for (int i = 0; i < size1; i++) {
        if (existsInArray(array2, size2, array1[i])) {
            printf("%d ", array1[i]);
        }
    }
}


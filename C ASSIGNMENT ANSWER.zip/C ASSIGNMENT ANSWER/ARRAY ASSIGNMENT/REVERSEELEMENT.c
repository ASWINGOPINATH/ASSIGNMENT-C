#include<stdio.h>
void main(){
    int a[20],s,i;
    printf("ENTER THE SIZE OF ARRAY:");
    scanf("%d",&s);
    printf("ENTER THE ELEMENT IN AN ARRAY:");
    for(i=0;i<s;i++){
        scanf("%d",&a[i]);
    }
    for (int i = 0; i < s/ 2; i++) {
    int temp = a[i];
    a[i] = a[s - i - 1];
    a[s - i - 1] = temp;
  }

  for (int i = 0; i < s; i++) {
    printf("%d ", a[i]);
  }

}
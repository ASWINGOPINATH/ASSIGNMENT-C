#include <stdio.h>

float c_f(float celsius) {
    return (celsius * 9.0 / 5.0) + 32;
}

float f_c(float fahrenheit) {
    return (fahrenheit - 32) * 5.0 / 9.0;
}

int main() {
    float temperature;
    int choice;
    printf("1. Convert Celsius to Fahrenheit\n");
    printf("2. Convert Fahrenheit to Celsius\n");
    printf("Enter your choice (1 or 2): ");
    scanf("%d", &choice);
    switch(choice) {
        case 1:
            printf("Enter temperature in Celsius: ");
            scanf("%f", &temperature);
            printf("Temperature in Fahrenheit: %.2f\n", c_f(temperature));
            break;
        case 2:
            printf("Enter temperature in Fahrenheit: ");
            scanf("%f", &temperature);
            printf("Temperature in Celsius: %.2f\n", f_c(temperature));
            break;
        default:
            printf("Invalid choice\n");
    }
}

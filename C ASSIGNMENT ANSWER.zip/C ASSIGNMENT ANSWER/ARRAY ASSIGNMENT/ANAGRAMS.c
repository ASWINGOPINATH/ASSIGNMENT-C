#include <stdio.h>
#include <string.h>

#define MAX_CHARS 256


int areAnagrams(char *str1, char *str2) {
    int count[MAX_CHARS] = {0};

    
    if (strlen(str1) != strlen(str2))
        return 0;


    for (int i = 0; str1[i] && str2[i]; i++) {
        count[str1[i]]++;
        count[str2[i]]--;
    }

    
    for (int i = 0; i < MAX_CHARS; i++) {
        if (count[i] != 0)
            return 0;
    }

    return 1;
}

int main() {
    char str1[MAX_CHARS], str2[MAX_CHARS];

    printf("Enter the first string: ");
    gets(str1);
    printf("Enter the second string: ");
    gets(str2);

    if (areAnagrams(str1, str2))
        printf("The strings are anagrams.\n");
    else
        printf("The strings are not anagrams.\n");

    return 0;
}

#include <stdio.h>
int main() {
    int a[20] ,i, j, t,n;
    printf("ENTER THE SIZE OF ARRAY:");
    scanf("%d",&n);
    printf("ENTER THE ARRAY ELEMENT:");
    for(i=0;i<n;i++){
        scanf("%d",&a[i]);
    } 
    for (i = 0; i < n-1; i++) {
        for (j = 0; j < n-i-1; j++) {
            if (a[j] > a[j+1]) {
                
                t = a[j];
                a[j] = a[j+1];
                a[j+1] = t;
            }
        }
    } 
    printf("Sorted array in ascending order: \n");
    for (int i = 0; i < n; i++)
        printf("%d ", a[i]);
    printf("\n");   
}


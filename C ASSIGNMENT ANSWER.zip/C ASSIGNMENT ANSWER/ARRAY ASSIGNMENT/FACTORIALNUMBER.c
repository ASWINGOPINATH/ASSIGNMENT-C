#include <stdio.h>
unsigned long long factorial(int n) {
    unsigned long long fact = 1;
    int i;
    for (i = 1; i <= n; ++i) {
        fact *= i;
    }
    
    return fact;
}
void main() {
    int num;
    printf("Enter a positive integer: ");
    scanf("%d", &num);
    if (num < 0) {
        printf("Error! Factorial of a negative number doesn't exist.");
    } else {
       
        printf("Factorial of %d = %llu\n", num, factorial(num));
    }
}

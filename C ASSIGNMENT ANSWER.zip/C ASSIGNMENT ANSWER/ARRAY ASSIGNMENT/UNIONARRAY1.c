#include <stdio.h>
#include <stdlib.h>


int isPresent(int *unionArr, int size, int num) {
    for (int i = 0; i < size; i++) {
        if (unionArr[i] == num)
            return 1; 
    }
    return 0; 
}

int* computeUnion(int *arr1, int size1, int *arr2, int size2, int *sizeUnion) {
    int maxSize = size1 + size2;
    int *unionArr = (int *)malloc(maxSize * sizeof(int));
    if (unionArr == NULL) {
        printf("Memory allocation failed.\n");
        exit(1);
    }

    int index = 0;
    for (int i = 0; i < size1; i++) {
        if (!isPresent(unionArr, index, arr1[i])) {
            unionArr[index] = arr1[i];
            index++;
        }
    }

    for (int i = 0; i < size2; i++) {
        if (!isPresent(unionArr, index, arr2[i])) {
            unionArr[index] = arr2[i];
            index++;
        }
    }

    *sizeUnion = index;
    return unionArr;
}

void main() {
    int size1, size2;
    
    printf("Enter the size of the first array: ");
    scanf("%d", &size1);

    int *arr1 = (int *)malloc(size1 * sizeof(int));
    if (arr1 == NULL) {
        printf("Memory allocation failed.\n");
        return 1;
    }

    printf("Enter the elements of the first array: ");
    for (int i = 0; i < size1; i++) {
        scanf("%d", &arr1[i]);
    }

    printf("Enter the size of the second array: ");
    scanf("%d", &size2);

    int *arr2 = (int *)malloc(size2 * sizeof(int));
    if (arr2 == NULL) {
        printf("Memory allocation failed.\n");
        free(arr1);
        return 1;
    }

    printf("Enter the elements of the second array: ");
    for (int i = 0; i < size2; i++) {
        scanf("%d", &arr2[i]);
    }

    int sizeUnion;
    int *unionArr = computeUnion(arr1, size1, arr2, size2, &sizeUnion);

    printf("Union of the two arrays: ");
    for (int i = 0; i < sizeUnion; i++) {
        printf("%d ", unionArr[i]);
    }
    printf("\n");

    free(arr1);
    free(arr2);
    free(unionArr);
}

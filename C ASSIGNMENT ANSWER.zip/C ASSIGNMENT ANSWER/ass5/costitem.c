#include <stdio.h>

void main() {
    char itemCode;
    float cost = 0;

    printf("Enter the item code: ");
    scanf(" %c", &itemCode);

    switch (itemCode) {
        case 'A':
        case 'a':
            cost = 10.50;
            break;
        case 'B':
        case 'b':
            cost = 20.75;
            break;
        case 'C':
        case 'c':
            cost = 15.00;
            break;
        case 'D':
        case 'd':
            cost = 12.25;
            break;
        default:
            printf("Invalid item code\n");
            return 1;
    }

    printf("Cost of item %c is: $%.2f\n", itemCode, cost);

   
}

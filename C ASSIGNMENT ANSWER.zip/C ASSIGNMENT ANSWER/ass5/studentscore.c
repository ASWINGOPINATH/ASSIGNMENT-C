#include <stdio.h>

void main() {
    int score;

    printf("Enter the student's score: ");
    scanf("%d", &score);

    if (score >= 90) {
        printf("Excellent\n");
    } else if (score >= 80) {
        printf("Good\n");
    } else if (score >= 70) {
        printf("Average\n");
    } else {
        printf("Poor\n");
    }
}

#include <stdio.h>

void main() {
   int quantity;
   float unit_price = 10.0;  
   float total_cost;

   printf("Enter the quantity purchased: ");
   scanf("%d", &quantity);

   if (quantity >= 100) {
       total_cost = quantity * unit_price * 0.85;  
       printf("Total cost (with 15%% discount): $%.2f\n", total_cost);
   } else if (quantity >= 50) {
       total_cost = quantity * unit_price * 0.90;  
       printf("Total cost (with 10%% discount): $%.2f\n", total_cost);
   } else {
       total_cost = quantity * unit_price;
       printf("Total cost: $%.2f\n", total_cost);
   }

}

#include <stdio.h>

void main() {
    int num1, num2, num3, num4;
    int largest;

    printf("Enter four numbers: ");
    scanf("%d %d %d %d", &num1, &num2, &num3, &num4);

    largest = num1;

    if (num2 > largest) {
        largest = num2;
    }
    if (num3 > largest) {
        largest = num3;
    }
    if (num4 > largest) {
        largest = num4;
    }

    printf("The largest number among %d, %d, %d, and %d is: %d\n", num1, num2, num3, num4, largest);
}

#include<stdio.h>
void main()
{
    float score;
    printf("ENTER A SCORE:");
    scanf("%f",&score);
    if(score>40){
        printf("STUDENT IS PASSED");
    }
    else{
        printf("STUDENT IS FAILED");
    }
}
#include <stdio.h>

void main() {
   int grade;

   printf("Enter a numerical grade: ");
   scanf("%d", &grade);

   if (grade < 0 || grade > 100) {
       printf("Invalid grade. Please enter a grade between 0 and 100.\n");
       return 1;  
   }

   grade = grade / 10;

   switch (grade) {
       case 10:
       case 9:
           printf("Letter grade: A\n");
           break;
       case 8:
           printf("Letter grade: B\n");
           break;
       case 7:
           printf("Letter grade: C\n");
           break;
       case 6:
           printf("Letter grade: D\n");
           break;
       default:
           printf("Letter grade: F\n");
   }

}

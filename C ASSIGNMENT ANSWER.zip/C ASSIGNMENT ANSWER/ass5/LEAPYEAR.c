#include<stdio.h>
void main(){
    int y;
    printf("ENTER THE YEAR:");
    scanf("%d",&y);
    if(y%4==0){
        printf("THE YEAR IS LEAPYEAR");
    }
    else{
        printf("THE YEAR IS NOT LEAP YEAR");
    }
}
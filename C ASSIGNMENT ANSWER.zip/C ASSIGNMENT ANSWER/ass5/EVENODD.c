#include<stdio.h>
void main()
{
    int n;
    printf("ENTER A NUMBER:");
    scanf("%d",&n);
    if(n%2==0){
        printf("THE NUMBER IS EVEN");
    
    }
    else{
        printf("THE NUMBER IS ODD");
    }
}
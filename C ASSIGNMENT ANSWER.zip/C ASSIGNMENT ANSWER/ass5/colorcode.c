#include <stdio.h>

void main() {
    int colorCode;

    printf("Enter color code (1 for Red, 2 for Blue, 3 for Green): ");
    scanf("%d", &colorCode);
    
    
    switch(colorCode) {
        case 1:
            printf("The color is Red.\n");
            break;
        case 2:
            printf("The color is Blue.\n");
            break;
        case 3:
            printf("The color is Green.\n");
            break;
        default:
            printf("Invalid color code.\n");
    }
    
    
}

#include <stdio.h>

void main() {
    char ch;

   
    printf("Enter a character: ");
    scanf(" %c", &ch);


    if ((ch >= 'a' && ch <= 'z') || (ch >= 'A' && ch <= 'Z')) {
        if (ch >= 'a' && ch <= 'z') {
            printf("The character entered is a lowercase letter.\n");
        } else {
            printf("The character entered is an uppercase letter.\n");
        }
    } else if (ch >= '0' && ch <= '9') {
        printf("The character entered is a digit.\n");
    } else {
        printf("The character entered is a symbol.\n");
    }
}

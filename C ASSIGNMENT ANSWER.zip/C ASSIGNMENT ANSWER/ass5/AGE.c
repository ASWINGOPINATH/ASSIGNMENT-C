#include <stdio.h>

void main() {
  int age;

  printf("Enter the age: ");
  scanf("%d", &age);

  if (age < 13) {
    printf("child\n");
  } else if (age >= 13 && age < 20) {
    printf("teenager\n");
  } else {
    printf("adult\n");
  }

  
}

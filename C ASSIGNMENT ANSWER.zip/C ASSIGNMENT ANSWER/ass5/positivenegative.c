#include<stdio.h>
void main()
{
    int n;
    printf("ENTER A NUMBER:");
    scanf("%d",&n);
    if(n>0){
        printf("THE NUMBER IS POSITIVE");
    }
    else{
        printf("THE NUMBER IS NEGATIVE");
    }

}
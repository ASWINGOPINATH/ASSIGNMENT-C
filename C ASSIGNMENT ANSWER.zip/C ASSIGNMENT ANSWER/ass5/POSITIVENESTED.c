#include <stdio.h>

void main() {
    float number;

    printf("Enter a number: ");
    scanf("%f", &number);

    if (number > 0) {
        printf("%.2f is a positive number.\n", number);
    } else if (number < 0) {
        printf("%.2f is a negative number.\n", number);
    } else {
        printf("The number is zero.\n");
    }

   
}

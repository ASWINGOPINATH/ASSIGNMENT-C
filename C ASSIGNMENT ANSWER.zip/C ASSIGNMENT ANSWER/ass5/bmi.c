#include <stdio.h>

void main() {
    float weight, height, bmi;


    printf("Enter weight (in kilograms): ");
    scanf("%f", &weight);
    printf("Enter height (in meters): ");
    scanf("%f", &height);

    bmi = weight / (height * height);

    if (bmi < 18.5) {
        printf("Your BMI is %.2f. You are underweight.\n", bmi);
    } else if (bmi >= 18.5 && bmi < 25) {
        printf("Your BMI is %.2f. You have a normal weight.\n", bmi);
    } else if (bmi >= 25 && bmi < 30) {
        printf("Your BMI is %.2f. You are overweight.\n", bmi);
    } else {
        printf("Your BMI is %.2f. You are obese.\n", bmi);
    }
}

#include <stdio.h>

void main() {
    int choice;

    printf("Select a shape:\n");
    printf("1. Square\n");
    printf("2. Circle\n");
    printf("3. Triangle\n");
    printf("Enter your choice (1-3): ");
    

    scanf("%d", &choice);

   
    switch (choice) {
        case 1:
            printf("You selected a Square.\n");
            break;
        case 2:
            printf("You selected a Circle.\n");
            break;
        case 3:
            printf("You selected a Triangle.\n");
            break;
        default:
            printf("Invalid choice. Please enter a number between 1 and 3.\n");
    }

}
